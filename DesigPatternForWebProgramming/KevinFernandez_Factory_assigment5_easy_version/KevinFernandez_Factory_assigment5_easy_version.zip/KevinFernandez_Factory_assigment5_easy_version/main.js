// start the application once the page is loaded
window.addEventListener('load', () => {
  new Application();
}, false);