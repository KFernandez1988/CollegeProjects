// Object Data that creates a Pet
class ODPet {
    constructor() {
        this.fullName = '';
        this.species = ''
        this.age = 0;
        this.ageInHumanYears = 0;
    }
}
//list of pets
ODPet.ListOfPets = [];
