//Kevin Fernandez Gonzalez MVC with Events assignment 4
// wait for the html page to load
window.addEventListener('load', () => {
  new Fernandez_DPW();
}, false);