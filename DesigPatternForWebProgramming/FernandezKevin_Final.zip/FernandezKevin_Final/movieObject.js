// Movie Object data
class MovieOD {
    constructor() {
        this.title = "";
        this.duration = "";
        this.rating = "";
    }
}

MovieOD.listOfMovies = [];