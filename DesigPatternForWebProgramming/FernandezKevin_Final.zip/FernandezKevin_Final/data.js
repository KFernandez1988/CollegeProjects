/**
 * Created by scottwainman on 10/20/16.
 */

var data = {
    movies: [
        {
            title: "Star Wars",
            duration: 127,
            rating: "PG"
        },
        {
            title: "Matrix",
            duration: 207,
            rating: "PG-13"
        },
        {
            title: "Aliens",
            duration: 86,
            rating: "R"
        }]

};
