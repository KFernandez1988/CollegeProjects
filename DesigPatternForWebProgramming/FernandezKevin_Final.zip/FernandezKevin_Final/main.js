
// waiting to the page to load so that the app can start
window.addEventListener('load', ()=> {
new Application();
});