// Wait until page load to run the application
window.addEventListener('load', () => {
  new Application();
}, false);