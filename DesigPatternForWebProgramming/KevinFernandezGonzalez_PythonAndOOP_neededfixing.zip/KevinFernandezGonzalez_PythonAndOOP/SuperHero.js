class SuperHero extends Person {
    // child class of person
    constructor(name, id, grades){
        //make hard code for hero
        super(name, id, "perfect", "Is Over 9000!", 'super');
    }
}