class Student extends Person {
//child class of person with base constructer
    constructor(name, id, grades, avg ){
        super(name, id, grades, 0, 'student');
    }

}
